const initData = {
  basicId: "AXUgjQvdZGmXuhpWo7iT",
  listBlood: [
    {
      id: "AXUgjQvdZGmXuhpWo7iT",
      tbname: "dwd_a1013",
      bloodfatherids: [
        "yFp2aTmiP2ReWSuG9QBd",
        "489VWegDkNA7lWsrLDVo",
        "-93871fUFoUxAq7Kgcf0",
        "NSaSce2b0aPqaLDNmPeo",
      ],
    },
    {
      id: "yFp2aTmiP2ReWSuG9QBd",
      tbname: "dwd_testllx",
      bloodfatherids: ["489VWegDkNA7lWsrLDVo", "iECOwr8n7t-2g9B5kvvA"],
    },
    {
      id: "489VWegDkNA7lWsrLDVo",
      tbname: "ods_test1",
      bloodfatherids: [],
    },
    {
      id: "iECOwr8n7t-2g9B5kvvA",
      tbname: "ods_pg_policies",
      bloodfatherids: [],
    },
    {
      id: "489VWegDkNA7lWsrLDVo",
      tbname: "ods_test1",
      bloodfatherids: [],
    },
    {
      id: "-93871fUFoUxAq7Kgcf0",
      tbname: "ods_pg_stat_bgwriter",
      bloodfatherids: ["VYL8Zb5egOrhlsU3bvJ1"],
    },
    {
      id: "VYL8Zb5egOrhlsU3bvJ1",
      tbname: "ods_pg_stats",
      bloodfatherids: ["i8QkQ2UjEMszqgqaFnf6"],
    },
    {
      id: "i8QkQ2UjEMszqgqaFnf6",
      tbname: "ods_pg_stat_sys_tables",
      bloodfatherids: ["489VWegDkNA7lWsrLDVo"],
    },
    {
      id: "489VWegDkNA7lWsrLDVo",
      tbname: "ods_test1",
      bloodfatherids: [],
    },
    {
      id: "NSaSce2b0aPqaLDNmPeo",
      tbname: "ods_pg_stat_ssl",
      bloodfatherids: ["489VWegDkNA7lWsrLDVo"],
    },
    {
      id: "489VWegDkNA7lWsrLDVo",
      tbname: "ods_test1",
      bloodfatherids: [],
    },
  ],
};

export default initData;
